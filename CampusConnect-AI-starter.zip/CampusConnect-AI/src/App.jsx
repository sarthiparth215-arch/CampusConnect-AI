import React, { useState } from 'react';
import { ArrowUp, BookOpen, GraduationCap, IndianRupee, House, BriefcaseBusiness, Phone, Sparkles, ShieldCheck, Clock3, Menu, X } from 'lucide-react';

const quickQuestions = [
  { label: 'Admissions', icon: GraduationCap, prompt: 'Tell me about the admission process.' },
  { label: 'Courses', icon: BookOpen, prompt: 'What courses are available?' },
  { label: 'Fees', icon: IndianRupee, prompt: 'Where can I find fee details?' },
  { label: 'Hostel', icon: House, prompt: 'Tell me about hostel facilities.' },
  { label: 'Placements', icon: BriefcaseBusiness, prompt: 'How can I learn about placements?' },
  { label: 'Contact', icon: Phone, prompt: 'How can I contact the college?' },
];

const demoAnswers = {
  admissions: 'I can help you understand the admission journey. In this starter demo, admission dates, eligibility rules and application links have not been added yet. Please check the college’s official admissions page or contact its admissions office for verified details.',
  courses: 'Course information is not connected to an official college catalogue yet. Add your college’s verified programme list, eligibility criteria and course pages to the knowledge base before using this for real enquiries.',
  fees: 'I don’t have verified fee data in this demo. Fees can vary by programme, year and accommodation choice, so please confirm the latest fee structure with the college accounts or admissions office.',
  hostel: 'Hostel availability, room types, rules and charges have not been configured yet. Please confirm these details with the college hostel office.',
  placements: 'Placement statistics and recruiter information have not been added. For accurate information, use the college’s latest placement report and verify the year, programme and figures.',
  contact: 'Official contact details are not configured yet. Add the college’s verified phone number, email address and campus address before publishing this assistant.',
};

function getDemoReply(message) {
  const q = message.toLowerCase();
  if (/(admission|apply|application|eligib|entrance)/.test(q)) return demoAnswers.admissions;
  if (/(course|program|programme|degree|branch|subject)/.test(q)) return demoAnswers.courses;
  if (/(fee|fees|cost|scholarship|payment)/.test(q)) return demoAnswers.fees;
  if (/(hostel|room|accommodation|mess)/.test(q)) return demoAnswers.hostel;
  if (/(placement|job|recruit|salary|company)/.test(q)) return demoAnswers.placements;
  if (/(contact|phone|email|address|location|reach)/.test(q)) return demoAnswers.contact;
  return 'Thanks for your question. This starter version is running in demo mode: it does not connect to an AI model or a live college database. Try one of the enquiry topics, or connect a verified knowledge base and an AI API in a later step to enable real answers.';
}

const initialMessages = [{
  role: 'assistant',
  text: 'Welcome to CampusConnect AI! 👋\nI’m your college enquiry guide. Ask me about admissions, courses, fees, hostel life, placements or how to contact the college.\n\nThis is a starter demo. I’ll clearly tell you when information has not been configured.'
}];

function App() {
  const [messages, setMessages] = useState(initialMessages);
  const [input, setInput] = useState('');
  const [mobileMenu, setMobileMenu] = useState(false);

  function sendMessage(text = input) {
    const clean = text.trim();
    if (!clean) return;
    setMessages(current => [...current, { role: 'user', text: clean }, { role: 'assistant', text: getDemoReply(clean) }]);
    setInput('');
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="#home" aria-label="CampusConnect AI home">
          <span className="brand-mark"><GraduationCap size={22} /></span>
          <span>CampusConnect <b>AI</b></span>
        </a>
        <button className="mobile-toggle" onClick={() => setMobileMenu(!mobileMenu)} aria-label="Toggle menu">{mobileMenu ? <X /> : <Menu />}</button>
        <nav className={mobileMenu ? 'nav-links open' : 'nav-links'}>
          <a href="#home" onClick={() => setMobileMenu(false)}>Home</a>
          <a href="#assistant" onClick={() => setMobileMenu(false)}>Ask a question</a>
          <a href="#features" onClick={() => setMobileMenu(false)}>Features</a>
        </nav>
        <a className="header-cta" href="#assistant">Try the assistant <span>↗</span></a>
      </header>

      <main>
        <section className="hero" id="home">
          <div className="hero-copy">
            <div className="eyebrow"><span className="pulse-dot"></span> YOUR CAMPUS, ONE CONVERSATION AWAY</div>
            <h1>Every college question.<br /><span>One clear answer.</span></h1>
            <p className="hero-description">Meet a simpler way to explore college life. Get guided towards the information you need, all in one friendly place.</p>
            <div className="hero-actions">
              <a className="primary-button" href="#assistant">Start asking <ArrowUp size={17} className="arrow-diagonal" /></a>
              <a className="text-button" href="#features">Explore features <span>↓</span></a>
            </div>
            <div className="hero-proof"><span className="proof-icon"><ShieldCheck size={17} /></span><span>Clear guidance, with demo limitations shown upfront</span></div>
          </div>
          <div className="hero-art" aria-label="CampusConnect assistant illustration">
            <div className="art-orbit orbit-one"></div><div className="art-orbit orbit-two"></div>
            <div className="art-card">
              <div className="art-card-top"><span className="tiny-logo"><Sparkles size={16} /></span><span className="online-label"><i></i> READY TO HELP</span></div>
              <div className="art-avatar"><GraduationCap size={42} /></div>
              <div className="art-title">Your campus guide</div>
              <div className="art-subtitle">A better starting point for every question.</div>
              <div className="art-suggestions"><span>Admissions</span><span>Courses</span><span>Campus life</span></div>
            </div>
            <div className="floating-note note-top"><span className="note-icon"><BookOpen size={16} /></span><span><b>Explore courses</b><small>Find your next step</small></span></div>
            <div className="floating-note note-bottom"><span className="note-icon green"><ShieldCheck size={16} /></span><span><b>Clarity first</b><small>No made-up college facts</small></span></div>
          </div>
        </section>

        <section className="assistant-section" id="assistant">
          <div className="section-heading">
            <div className="eyebrow">THE ENQUIRY DESK</div>
            <h2>What would you like to know?</h2>
            <p>Choose a topic or type your question below.</p>
          </div>
          <div className="chat-layout">
            <aside className="topic-panel">
              <div className="topic-heading">POPULAR TOPICS <span>06</span></div>
              {quickQuestions.map(({ label, icon: Icon, prompt }) => (
                <button className="topic-button" key={label} onClick={() => sendMessage(prompt)}>
                  <span className="topic-icon"><Icon size={17} /></span><span>{label}</span><span className="topic-chevron">›</span>
                </button>
              ))}
              <div className="topic-help"><Sparkles size={17} /><b>Not sure where to start?</b><p>Pick any topic. You can ask in your own words too.</p></div>
            </aside>
            <section className="chat-card" aria-label="College enquiry chat">
              <div className="chat-header">
                <div className="chat-agent-icon"><Sparkles size={19} /></div>
                <div className="chat-agent-info"><b>CampusConnect Assistant</b><span><i></i> Demo mode · API not connected</span></div>
                <span className="chat-header-tag">ENQUIRY DESK</span>
              </div>
              <div className="chat-messages" aria-live="polite">
                {messages.map((message, index) => (
                  <div className={`message-row ${message.role}`} key={index}>
                    {message.role === 'assistant' && <div className="message-avatar"><Sparkles size={14} /></div>}
                    <div className="message-content"><span className="message-sender">{message.role === 'assistant' ? 'CAMPUSCONNECT' : 'YOU'}</span><div className="message-bubble">{message.text}</div></div>
                  </div>
                ))}
              </div>
              <div className="demo-notice"><span>ⓘ</span> Demo replies only. No AI model or official college data is connected.</div>
              <form className="chat-input-area" onSubmit={e => { e.preventDefault(); sendMessage(); }}>
                <input value={input} onChange={e => setInput(e.target.value)} placeholder="Type your college question here..." aria-label="Type your college question" />
                <button type="submit" disabled={!input.trim()} aria-label="Send message"><ArrowUp size={19} /></button>
              </form>
              <div className="input-caption">Press Enter to send <span>•</span> Please don’t share passwords or private information</div>
            </section>
          </div>
        </section>

        <section className="features-section" id="features">
          <div className="section-heading">
            <div className="eyebrow">MADE FOR STUDENT QUESTIONS</div>
            <h2>A smarter starting point.</h2>
            <p>Everything you need to begin exploring your college options.</p>
          </div>
          <div className="feature-grid">
            <article className="feature-card"><div className="feature-icon blue"><MessageIcon /></div><h3>Simple conversations</h3><p>Ask questions in everyday language through a clean, approachable chat interface.</p></article>
            <article className="feature-card"><div className="feature-icon violet"><BookOpen size={21} /></div><h3>Quick topic access</h3><p>Jump straight to admissions, courses, fees, hostel, placements and contact topics.</p></article>
            <article className="feature-card"><div className="feature-icon mint"><ShieldCheck size={21} /></div><h3>Transparent by design</h3><p>Demo mode is clearly labelled, so sample guidance is never presented as live AI knowledge.</p></article>
          </div>
        </section>
      </main>
      <footer><a className="brand footer-brand" href="#home"><span className="brand-mark"><GraduationCap size={19} /></span><span>CampusConnect <b>AI</b></span></a><span>Built to make college enquiries feel simpler.</span><span>© 2026 CampusConnect AI · Starter demo</span></footer>
    </div>
  );
}

function MessageIcon() {
  return <svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8z"/></svg>;
}

export default App;
