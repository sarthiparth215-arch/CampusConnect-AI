# CampusConnect AI

A beginner-friendly React + Vite starter for a college enquiry assistant.

## What works now
- Responsive homepage and features section
- Chat interface with student and assistant messages
- Quick enquiry topic buttons
- Local demo replies for common enquiry categories
- Clear labels explaining that no AI API or official college database is connected

## What does NOT work yet
This is not connected to an AI model, college website, database, or live college records. The replies are simple local demo responses and deliberately do not invent college-specific facts.

## Run it on your computer

1. Install **Node.js LTS** from https://nodejs.org/ . This also installs npm.
2. Unzip this project folder.
3. Open the `CampusConnect-AI` folder in your code editor (VS Code is a good option).
4. Open the editor's Terminal menu and choose New Terminal.
5. Run:

   ```bash
   npm install
   npm run dev
   ```

6. The terminal will show a local address, usually `http://localhost:5173/`. Open that address in your browser.
7. To stop the app, click the terminal and press `Ctrl + C` (on Mac, `Control + C`).

## Build check

Run `npm run build`. Vite creates a production build in the `dist` folder.

## Next development step

Before connecting real AI, choose the exact college and provide approved, accurate information (admissions, programmes, fees, hostel, placements and official contacts). Then choose an AI provider and review its cost, privacy and API-key requirements. Never put a secret API key directly in frontend code.
